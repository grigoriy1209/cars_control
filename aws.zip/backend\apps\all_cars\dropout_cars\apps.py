from django.apps import AppConfig


class DropoutCarsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.all_cars.dropout_cars'
