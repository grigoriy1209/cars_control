from django.apps import AppConfig


class DealerAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.partners.dealer_admin'
